TARGET_CLASSES = {
  0: "COVID19",
  1: "Normal"
 // 2: "VP"
};