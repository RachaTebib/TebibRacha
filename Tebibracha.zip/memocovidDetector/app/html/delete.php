<?php 

require_once ('connect.php');

  $id = $_GET['id'];
  $DelSql = "DELETE FROM `malade` WHERE id=$id";

  $res = mysqli_query($con, $DelSql);
  if ($res) {
    header("Location: listemalade.php");
  }else{
    echo "Failed to delete";
  }

 ?>

